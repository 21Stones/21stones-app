# 21 Stones Accounting LLC — Time Management System

Sistema de gestión de tiempo con base de datos real (SQLite), backend Node.js/Express, y frontend completo.

---

## 🚀 DEPLOY EN RAILWAY (recomendado — gratis)

### Paso 1 — Crear cuenta
Ir a **https://railway.app** → Sign Up con GitHub (gratis).

### Paso 2 — Subir el código a GitHub
```bash
# En la carpeta de este proyecto:
git init
git add .
git commit -m "21 Stones Time Management System"

# Crear repo en github.com, luego:
git remote add origin https://github.com/TU_USUARIO/21stones-app.git
git push -u origin main
```

### Paso 3 — Deploy en Railway
1. En Railway → **New Project** → **Deploy from GitHub repo**
2. Seleccionar tu repositorio `21stones-app`
3. Railway detecta automáticamente Node.js y hace el deploy
4. En **Settings → Networking** → **Generate Domain** → copiar la URL pública

¡Listo! La app estará en `https://tu-app.railway.app`

---

## 🌐 DEPLOY EN RENDER (alternativa gratis)

### Paso 1
Ir a **https://render.com** → Sign Up con GitHub.

### Paso 2 — Subir a GitHub (igual que arriba)

### Paso 3 — Crear Web Service en Render
1. **New** → **Web Service**
2. Conectar el repositorio de GitHub
3. Configurar:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment:** `Node`
4. **Create Web Service**

> ⚠️ **Nota Render:** El plan gratuito duerme la app después de 15 min de inactividad.
> Railway no tiene este problema.

---

## 💻 CORRER LOCAL (para pruebas)

```bash
# Instalar dependencias
npm install

# Iniciar servidor
npm start

# Abrir en navegador
http://localhost:3000
```

---

## 👤 CREDENCIALES INICIALES

| Empleado | Código | Contraseña | Nivel |
|---|---|---|---|
| Alexandra Rivera | EMP-001 | emp001 | Employee |
| Michael Torres | EMP-002 | emp002 | Employee |
| David Okafor | EMP-003 | emp003 | Employee |
| Sandra Lee | MGR-001 | mgr001 | Manager |
| James Whitfield | MGR-002 | mgr002 | Manager |
| Patricia Monroe | PTR-001 | ptr001 | Partner |

> Cambiar contraseñas desde **Admin → Employees** después del primer login.

---

## 🗄️ BASE DE DATOS

- **Motor:** SQLite (archivo `21stones.db`)
- **Ubicación:** `db/21stones.db` (se crea automáticamente al iniciar)
- **No requiere** instalación de PostgreSQL ni MySQL
- En Railway/Render el archivo persiste en el servidor

### Backup de datos
```bash
# Descargar copia de la base de datos desde el servidor
# Railway → tu proyecto → Files → db/21stones.db → Download
```

---

## 📁 ESTRUCTURA DEL PROYECTO

```
21stones-app/
├── server.js          ← API REST + servidor Express
├── db/
│   ├── database.js    ← Configuración SQLite + datos iniciales
│   └── 21stones.db    ← Base de datos (se genera automáticamente)
├── public/
│   └── index.html     ← Frontend completo (HTML + CSS + JS)
├── package.json
├── railway.toml       ← Config de Railway
└── .gitignore
```

---

## 🔐 FLUJO DE APROBACIONES

```
Empleado → Envía horas
    ↓
Manager → Revisa y aprueba (1er nivel)
    ↓
Partner → Revisa y aprueba (2do nivel)
    ↓
Status: APPROVED → listo para transferir

Manager → Envía horas → Partner aprueba directamente
Partner → Envía horas → Auto-aprobado inmediatamente
```

---

## 🔧 VARIABLES DE ENTORNO (opcional)

| Variable | Default | Descripción |
|---|---|---|
| `PORT` | 3000 | Puerto del servidor |
| `DB_PATH` | `./db` | Carpeta de la base de datos |

En Railway se configuran en **Settings → Variables**.
